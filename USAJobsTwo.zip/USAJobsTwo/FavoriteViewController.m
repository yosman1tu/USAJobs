//
//  FavoriteViewController.m
//  USAJobs
//
//  Created by Yahya  on 8/19/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "FavoriteViewController.h"
#import "FavoriteTableViewCell.h"
#import "USAJobObject.h"
#import "AppDelegate.h"


#import "JobInfo.h"
#import "SearchingViewController.h"
#import "FavoriteDetailView.h"


@interface FavoriteViewController ()

@end

@implementation FavoriteViewController
@synthesize array, mutableArray;
@synthesize managedObjectContext;
@synthesize fetchedResultsController = _fetchedResultsController;



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

//-(void)deleteAllObjectsFrom:(NSString*)entity
//                  inContext:(NSManagedObjectContext*)context {
//    
//    NSFetchRequest *request;
//    request = [NSFetchRequest fetchRequestWithEntityName:entity];
//    request.entity = [NSEntityDescription entityForName:entity
//                                 inManagedObjectContext:context];
//    
//    NSError *error = nil;
//    NSArray *entityObjects = [context executeFetchRequest:request
//                                                    error:&error];
//    
//    for (NSManagedObject *object in entityObjects) {
//        [context deleteObject:object];
//        NSLog(@"\n\nDeleted: \n\n%@.", object);
//    }
//}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        NSError *error;
        
        // Delete object from database
        NSManagedObjectContext *context = [self managedObjectContext];
        [context deleteObject:[mutableArray objectAtIndex:indexPath.row]];
        [context save:&error];

        
        // Remove the row from data model
        [mutableArray removeObjectAtIndex:indexPath.row];
        
        [tableView reloadData];
        //[myTableView reloadData];
        [tableView layoutIfNeeded];
        }

    //[sender setTitle:@"Remo" forState:UIControlStateNormal];


    
    else if (editingStyle==UITableViewCellEditingStyleInsert)
    {
        
    }

    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    array = [[NSMutableArray alloc] init];
    mutableArray = [[NSMutableArray alloc] init];
    // Do any additional setup after loading the view.
    
    
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    managedObjectContext = [appDelegate managedObjectContext];
    
    //self.myArray = [[appDelegate getAllUserRecords]mutableCopy];
    
    NSError *error;
    if (![[self fetchedResultsController] performFetch:&error]) {
        // Update to handle the error appropriately.
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        exit(-1);  // Fail
        
        
    }
    
    [_fetchedResultsController performFetch:nil];
    
    
    //[mutableArray addObject:_fetchedResultsController];
    
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"JobsEntity" inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    
    NSArray *fetchedObjects = [context executeFetchRequest:fetchRequest error:&error];
    
    //NSFetchRequest *request;
    //request = [NSFetchRequest fetchRequestWithEntityName:entity];
   // request.entity = [NSEntityDescription entityForName:entity
                                // inManagedObjectContext:context];
    
    //NSError *error = nil;
    //NSArray *entityObjects = [context executeFetchRequest:request
                                                    //error:&error];
    
    
    for (JobInfo *obj in fetchedObjects){
        
        
        [mutableArray addObject:obj];
    }
    
    
    
    [self.FavoriteTableView reloadData];

    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    



    

 

}


//New Begining



- (void)viewDidUnload {
    self.fetchedResultsController = nil;
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section {
//    id  sectionInfo =
//    [[_fetchedResultsController sections] objectAtIndex:section];
//    return [sectionInfo numberOfObjects];
    
   
    
    return mutableArray.count;
    
}

- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
   // JobInfo *info = [_fetchedResultsController objectAtIndexPath:indexPath];
    
    JobInfo *info = [mutableArray objectAtIndex:indexPath.row];

     //[cell setFavDetails:info];
    //[cell setFavDetails:info];
    


    
//    
   // cell.textLabel.text = info.jobsTitle;
    //cell.detailTextLabel.text = [NSString stringWithFormat:@"%@, %@",
                               //  info.orgName, info.departName];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"FavoriteCell";
    
    FavoriteTableViewCell *cell =
    [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Set up the cell...
    [self configureCell:cell atIndexPath:indexPath];
    
   // JobInfo *info = [_fetchedResultsController objectAtIndexPath:indexPath];
    
    
    JobInfo *info = [mutableArray objectAtIndex:indexPath.row];
    
    [cell setFavDetails:info];
    
   

    
    [_FavoriteTableView reloadData];

    
    
    return cell;
}



- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
    // The fetch controller is about to start sending change notifications, so prepare the table view for updates.
    [self.FavoriteTableView beginUpdates];
}


- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(NSIndexPath *)newIndexPath {
    
    UITableView *tableView = self.FavoriteTableView;
    
    switch(type) {
            
        case NSFetchedResultsChangeInsert:
            [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeUpdate:
            [self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
            break;
            
        case NSFetchedResultsChangeMove:
            [tableView deleteRowsAtIndexPaths:[NSArray
                                               arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView insertRowsAtIndexPaths:[NSArray
                                               arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}


- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id )sectionInfo atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type {
    
    switch(type) {
            
        case NSFetchedResultsChangeInsert:
            [self.FavoriteTableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [self.FavoriteTableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}


- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    // The fetch controller has sent all current change notifications, so tell the table view to process all updates.
    [self.FavoriteTableView endUpdates];
}



- (NSFetchedResultsController *)fetchedResultsController {
    
    
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    managedObjectContext = [appDelegate managedObjectContext];
    
    if (_fetchedResultsController != nil) {
        return _fetchedResultsController;
    }
    
    
    //do fetchRequest!
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription
                                   entityForName:@"JobsEntity" inManagedObjectContext:managedObjectContext];
    
    [fetchRequest setEntity:entity];

    
    NSSortDescriptor *sort = [[NSSortDescriptor alloc]
                              initWithKey:@"displayOrder" ascending:YES];
    
    [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sort]];
    
    [fetchRequest setFetchBatchSize:20];
    
    
    //cretae FetchResultsController with context, sectionNameKeyPath, and you can cache here so the next work if the
    
    NSFetchedResultsController *theFetchedResultsController =
    [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest
                                        managedObjectContext:managedObjectContext sectionNameKeyPath:nil
                                                   cacheName:nil];
    
    self.fetchedResultsController = theFetchedResultsController;
    _fetchedResultsController.delegate = self;
    
    
    
    
    // Perform Fetch
    NSError *error = nil;
    //[self.fetchedResultsController performFetch:&error];
    
    if (error) {
        NSLog(@"Unable to perform fetch.");
        NSLog(@"%@, %@", error, error.localizedDescription);
    }
    
    
   
    
    return _fetchedResultsController;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    FavoriteDetailView *detailViewController = [storyboard instantiateViewControllerWithIdentifier:@"FavoriteDetailView"];
    
    
    
    detailViewController.objectManager = [mutableArray objectAtIndex:indexPath.row];
    

    
    [self.navigationController pushViewController:detailViewController animated:YES];
    
}



@end
