//
//  ViewController.m
//  USAJobs
//
//  Created by Yahya  on 7/19/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "SearchingViewController.h"

//#import "TableViewController.h"
#import "TableViewCell.h"
#import "WebViewController.h"
#import "USAJobObject.h"
#import "JobDetailViewController.h"

#import "FavoriteViewController.h"
#import "FavoriteTableViewCell.h"
#import "AppDelegate.h"



@interface SearchingViewController ()


{
    
    NSMutableData *webData;
    NSURLConnection *connection;
    
}


@end
@implementation SearchingViewController
@synthesize jsonContent,contentItem, FavoriteArray;
static NSString *CellIdentifier = @"FavoriteCell";


//@synthesize jsonContent;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    FavoriteArray = [[NSMutableArray alloc] init];
    arrayData = [[NSMutableArray alloc] init];
    arrayToDelete = [[NSMutableArray alloc] init];
    
    
    
    contentItem = [[NSMutableArray alloc]init];
    jsonTitle = [[NSMutableArray alloc]init];
    jsonContent = [[NSMutableArray alloc]init];
    
    searchDisplayController.searchResultsDataSource = self;
    searchDisplayController.searchResultsDelegate = self;


  

    
    [self loadDetails];
    [self keyword];
    
    
    
    
}





-(void)keyword
{
    NSString *testToken = @"Fsm99W2PI/h/rzG8wNk5o8Dnfhol3eLxtVk0HaNLyyw=";
    //NSURL *url = [NSURL URLWithString:@"https://data.usajobs.gov/api/search?Keyword=Software"];
    
    NSURL *url = [NSURL URLWithString:@"https://data.usajobs.gov/api/Search?KeywordFilter=ALL&JobCategoryCode=2210%3b&ExcludeJOAOpenFor30Days=False&WhoMayApply=public&Student=False&fields=all"];
    //NSString *headerValue = [NSString stringWithFormat:@"Authorization: Token %@" , testToken];
    NSMutableURLRequest *loginRequest = [[NSMutableURLRequest alloc] initWithURL:url];
    loginRequest.HTTPMethod = @"GET";
    
    [loginRequest setValue:@"data.usajobs.gov" forHTTPHeaderField:@"Host"];
    [loginRequest setValue:@"nitin@pnautomation.com" forHTTPHeaderField:@"User-Agent"];
    
    [loginRequest setValue:@"Fsm99W2PI/h/rzG8wNk5o8Dnfhol3eLxtVk0HaNLyyw=" forHTTPHeaderField:@"Authorization-Key"];
    
    //[loginRequest addValue:testToken forHTTPHeaderField:@"Authorization"];
    
    
    
    //http://dev.usajobs.gov/JobSearch/Search/GetResults?LocationName=%@&Keyword=%@
    
    //AddValue
    NSURLResponse *response = nil;
    
    NSData *data = [NSURLConnection sendSynchronousRequest:loginRequest returningResponse:&response error:nil];
    NSString *txt = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
    ///////////////
    
    NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSDictionary *SearchDic =  [allDataDictionary objectForKey:@"SearchResult"];
    
    
    NSArray *arrayOfEntry = [SearchDic objectForKey:@"SearchResultItems"];
    
    allItems  = [[NSMutableArray alloc] init];
    
    
    //NSLog(@"Content: %@", arrayOfEntry);
    
    for(NSDictionary *diction in arrayOfEntry){
        
        
        USAJobObject *jobItem = [[USAJobObject alloc]init];
        
        NSDictionary *MatchD = [diction objectForKey:@"MatchedObjectDescriptor"];
        
        //[jsonTitle addObject:GetIt];
        jobItem.myTitle = [MatchD objectForKey:@"PositionTitle"];
        jobItem.OrgName = [MatchD objectForKey:@"OrganizationName"];
        jobItem.DepartName = [MatchD objectForKey:@"DepartmentName"];
        //jobItem.Location = [MatchD objectForKey:@"LocationName"];
        jobItem.DateOpen = [MatchD objectForKey:@"PositionStartDate"];
        jobItem.DateClose = [MatchD objectForKey:@"PositionEndDate"];
        jobItem.ApplyUrl= [MatchD objectForKey:@"PositionURI"];
        jobItem.PositionId= [MatchD objectForKey:@"PositionID"];
        
        // NSString *title = [MatchD objectForKey:@"PositionTitle"];
        
        //jobItem.ApplyUrl= [MatchD objectForKey:@"PositionURI"];
        
        
        
        NSString *contentItemUrl = [MatchD objectForKey:@"PositionURI"];
        
        
        
        
        
        [contentItem addObject:contentItemUrl];
        
        
        NSLog(@"Search boy COntentXXX: %@", contentItem);
        
        [allItems addObject:jobItem];
        
        
        
        NSLog(@"Search boy DATA: %@", allItems);
        
        
        
        NSArray *Array = [MatchD objectForKey:@"PositionLocation"];
        
        
        for(NSDictionary *Dict in Array){
            jobItem.Location = [Dict objectForKey:@"CityName"];
            //[jsonTitle addObject:GetIt];
            
        }
    }
    
    
    
}

- (void)loadDetails {
    
    
    //NSString *testToken = @"Fsm99W2PI/h/rzG8wNk5o8Dnfhol3eLxtVk0HaNLyyw=";
    //NSURL *url = [NSURL URLWithString:@"https://data.usajobs.gov/api/search?JobCategoryCode=2210"];
    
    NSURL *url = [NSURL URLWithString:@"https://data.usajobs.gov/api/Search?KeywordFilter=ALL&JobCategoryCode=2210%3b&ExcludeJOAOpenFor30Days=False&WhoMayApply=public&Student=False&fields=all"];
    
    
    //NSString *headerValue = [NSString stringWithFormat:@"Authorization: Token %@" , testToken];
    NSMutableURLRequest *loginRequest = [[NSMutableURLRequest alloc] initWithURL:url];
    loginRequest.HTTPMethod = @"GET";
    
    [loginRequest setValue:@"data.usajobs.gov" forHTTPHeaderField:@"Host"];
    [loginRequest setValue:@"nitin@pnautomation.com" forHTTPHeaderField:@"User-Agent"];
    
    [loginRequest setValue:@"Fsm99W2PI/h/rzG8wNk5o8Dnfhol3eLxtVk0HaNLyyw=" forHTTPHeaderField:@"Authorization-Key"];
    
  
    
    //AddValue
    NSURLResponse *response = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:loginRequest returningResponse:&response error:nil];
    NSString *txt = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
    connection = [NSURLConnection connectionWithRequest:loginRequest delegate:self];
    
    if(connection)
    {
        webData = [[NSMutableData alloc] init];
    }
    
    
    // [self keyword];
    
    
    
    
}


-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData setLength: 0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    
    [webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"fail with error");
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:webData options:0 error:nil];
    NSDictionary *SearchDic =  [allDataDictionary objectForKey:@"SearchResult"];
    //NSArray *arrayOfEntry = [feed objectForKey:@"entry"];
    
    NSArray *arrayOfEntry = [SearchDic objectForKey:@"SearchResultItems"];
    
    //NSLog(@"Content: %@", arrayOfEntry);
    
    for(NSDictionary *diction in arrayOfEntry){
        
        USAJobObject *GetIt = [[USAJobObject alloc]init];
        
        
        NSDictionary *MatchD = [diction objectForKey:@"MatchedObjectDescriptor"];
        
        //[jsonTitle addObject:GetIt];
        GetIt.myTitle = [MatchD objectForKey:@"PositionTitle"];
        
        GetIt.OrgName = [MatchD objectForKey:@"OrganizationName"];
        GetIt.DepartName = [MatchD objectForKey:@"DepartmentName"];
        GetIt.DateOpen = [MatchD objectForKey:@"PositionStartDate"];
        GetIt.DateClose = [MatchD objectForKey:@"PositionEndDate"];
        
        GetIt.ApplyUrl = [MatchD objectForKey:@"PositionURI"];
        GetIt.PositionId = [MatchD objectForKey:@"PositionID"];
        

        
        NSString *content = [MatchD objectForKey:@"PositionURI"];
        
        
        
        [jsonContent addObject:content];
        [jsonTitle addObject:GetIt];
        
        //[FavoriteArray addObject:GetIt];
        
        NSLog(@"Filter First: %@", jsonTitle);
        
        
        
        
        NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        
        NSString  *documentsDirectory = [paths objectAtIndex:0];
        NSString  *filePath = [NSString stringWithFormat:@"%@/%@", documentsDirectory,@"file.mp4"];
        
        
        //NiceController *GetWord = [[NiceController alloc]init];
        
        
        
        
        /////////////////////////////////////////////////
        
        
        NSArray *Array = [MatchD objectForKey:@"PositionLocation"];
        
        
        for(NSDictionary *Dict in Array){
            GetIt.Location = [Dict objectForKey:@"CityName"];
            //[jsonTitle addObject:GetIt];
            
        }
        
        
        
    }
    [myTableView reloadData];
    
    
    // [[self myTableView]reloadData];
    
    
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
    
    [myTableView reloadData];
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    
    // Dispose of any resources that can be recreated.
}




-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{


    FavoriteViewController *detail = segue.destinationViewController;


    if([segue.identifier isEqualToString:@"Favorite"]){




    }
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(isFilltered)
        // if (tableView == self.searchDisplayController.searchResultsTableView)
    {
        return [filteredString count];
    }
    

    return [jsonTitle count];
    
    
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    
    
    static NSString *CellIdentifier = @"Cell";
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    
    if(!cell)
    {
        cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
        
    }
    
    
    
    cell.FavBtn.tag = indexPath.row;
    [cell.FavBtn addTarget:self action:@selector(FavoriteBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    cell.shareButton.tag = indexPath.row;
    [cell.shareButton addTarget:self action:@selector(shareActionButton:) forControlEvents:UIControlEventTouchUpInside];
    
    //[self.view endEditing:YES];
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    request.entity = [NSEntityDescription entityForName:@"JobsEntity" inManagedObjectContext:context];
    
    
    if(!isFilltered)
    {
        
        USAJobObject *Get = [jsonTitle objectAtIndex:indexPath.row];
        
        
        [cell setDetails:Get];
        
        
       
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"positionID = %@", Get.PositionId];
        request.predicate = predicate;
        NSError *error = nil;
        NSArray *fetchObjects = [context executeFetchRequest:request error:&error];

        
        if(fetchObjects.count > 0)
        {
            //[cell.FavBtn setTitle:@"saved" forState:UIControlStateNormal];
            UIImage *btnImage1 = [UIImage imageNamed:@"USALoveB.png"];
            [cell.FavBtn setImage:btnImage1 forState:UIControlStateNormal];

            //cell.FavBtn.frame = CGRectMake(0.0, 0.0, btnImage1.size.width, btnImage1.size.height);


            

        }else{
            //[cell.FavBtn setTitle:@"Empt" forState:UIControlStateNormal];
            UIImage *btnImage2 = [UIImage imageNamed:@"USALoveA.png"];
            [cell.FavBtn setImage:btnImage2 forState:UIControlStateNormal];
//            cell.FavBtn.frame = CGRectMake(0.0, 0.0, btnImage2.size.width, btnImage2.size.height);

        }

        
    }
    else
    {
        
        
        
        USAJobObject *Get = [filteredString objectAtIndex:indexPath.row];
        
        [cell setDetails:Get];
        
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"positionID = %@", Get.PositionId];
        request.predicate = predicate;
        NSError *error = nil;
        NSArray *fetchObjects = [context executeFetchRequest:request error:&error];
        
        
        if(fetchObjects.count > 0)
        {
            //[cell.FavBtn setTitle:@"saved" forState:UIControlStateNormal];
            UIImage *btnImage1 = [UIImage imageNamed:@"USALoveB.png"];
            [cell.FavBtn setImage:btnImage1 forState:UIControlStateNormal];
            
            //cell.FavBtn.frame = CGRectMake(0.0, 0.0, btnImage1.size.width, btnImage1.size.height);
            
            
            
            
        }else{
            //[cell.FavBtn setTitle:@"Empt" forState:UIControlStateNormal];
            UIImage *btnImage2 = [UIImage imageNamed:@"USALoveA.png"];
            [cell.FavBtn setImage:btnImage2 forState:UIControlStateNormal];
            //            cell.FavBtn.frame = CGRectMake(0.0, 0.0, btnImage2.size.width, btnImage2.size.height);
            
        }
        
    
        
    }
    
 
    
    
    return cell;
}





- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
    
    
    
    if(isFilltered){
        //[tableView deselectRowAtIndexPath:indexPath animated:YES];
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        JobDetailViewController *detailViewController = [storyboard instantiateViewControllerWithIdentifier:@"JobDetailViewController"];
        
        // indexPath = [myTableView indexPathForSelectedRow];
        
        
        
        detailViewController.great = [filteredString objectAtIndex:indexPath.row];
        
       
        
        [self.navigationController pushViewController:detailViewController animated:YES];
        
        NSLog(@"Search Display Second");
        
//        [myTableView reloadData];
        
       
    }else{
        NSLog(@"Search Display One");
        
        //[myTableView reloadData];
        
        
        // [arrayToDelete addObject:arrayData[indexPath.row]];
        
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        WebViewController *detailViewController = [storyboard instantiateViewControllerWithIdentifier:@"WebViewController"];
        
        detailViewController.great = [jsonTitle objectAtIndex:indexPath.row];
        
        
        detailViewController.contentText = [jsonContent objectAtIndex:indexPath.row];
     
        
        [self.navigationController pushViewController:detailViewController animated:YES];
        
        
        
    }
    
    
}


-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //[arrayToDelete removeObject:arrayData[indexPath.row]];
}


- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    //self.navigationController.navigationBar.hidden = TRUE;
    CGRect r = self.view.frame;
    r.origin.y = -1;
    r.size.height += 44;
    self.view.frame = r;
    
    searchBar.text = nil;
    

    
    [searchBar setShowsCancelButton:YES animated:YES];
    
    
    
}



- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar {
   
    
    searchBar.text = nil;
    
    isFilltered = false;
    
    [searchBar setShowsCancelButton:NO animated:YES];
    
    [myTableView reloadData];
    
    [searchBar resignFirstResponder];
    
}



-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    
    
    if(searchText.length == 0)
    {
        isFilltered = NO;
    }else
    {
        isFilltered = YES;
        // filteredString = [[NSMutableArray alloc]init];
        filteredString = [[NSMutableArray alloc]init];
        
        for (USAJobObject *dict in allItems) {
            
            NSString *string1 = dict.myTitle;
            NSString *string2 = dict.OrgName;
            NSString *string3  = dict.DepartName;
            NSString *string4  = dict.Location;
            
            
            NSRange range1 = [string1 rangeOfString:searchText options:NSCaseInsensitiveSearch];
            
            NSRange range2 = [string2 rangeOfString:searchText options:NSCaseInsensitiveSearch];
            
            NSRange range3 = [string3 rangeOfString:searchText options:NSCaseInsensitiveSearch];
            
            NSRange range4 = [string4 rangeOfString:searchText options:NSCaseInsensitiveSearch];
            
            
            if (range1.location != NSNotFound) {
                [filteredString addObject:dict];
                
                //NSLog(@"This is filter me: %@", filteredString);
            }else if(range2.location != NSNotFound) {
                [filteredString addObject:dict];
                
            }else if(range3.location != NSNotFound) {
                [filteredString addObject:dict];
                
            }
            else if(range4.location != NSNotFound) {
                        [filteredString addObject:dict];
            }
            
        }
        
    }
    
    [myTableView reloadData];
    
    
}

- (NSManagedObjectContext *)managedObjectContext{
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication]delegate];
    if([delegate performSelector:@selector(managedObjectContext)]){
        context = [delegate managedObjectContext];
    }
    return context;
}


- (IBAction)FavoriteBtn:(id)sender {
    
    if(!isFilltered){
    
    NSLog(@"Tapped on favorite!");
    
    UIButton *senderButton = (UIButton *)sender;
    
    NSLog(@"Current row is: =%ld", (long)senderButton.tag);
    
    
    
    USAJobObject *NewObject = [jsonTitle objectAtIndex:senderButton.tag];
    
    NSString *string1 = NewObject.myTitle;
    NSString *string2 = NewObject.OrgName;
    NSString *string3  = NewObject.DepartName;
    NSString *string4  = NewObject.Location;
    NSString *string5  = NewObject.DateOpen;
    NSString *string6  = NewObject.DateClose;
    NSString *string7 = NewObject.ApplyUrl;
    NSString *string8 = NewObject.PositionId;
    //NSString *string8;
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    request.entity = [NSEntityDescription entityForName:@"JobsEntity" inManagedObjectContext:context];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"positionID = %@", string8];
    request.predicate = predicate;
    NSError *error = nil;
    NSArray *fetchObjects = [context executeFetchRequest:request error:&error];
    if (error) {
        [NSException raise:@"no job found" format:@"%@", [error localizedDescription]];
    }
    
    if (fetchObjects.count > 0) {
        
        // There is a job with same id exsist. Use update method
        [request setPredicate:predicate];

        NSLog(@"UpdatingSQ.....");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Alert?" message:@"Are you sure you want to delete this item from favorite list?" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"Yes!" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
            
            
            // Delete object from database
            NSManagedObjectContext *context = [self managedObjectContext];
            //[context deleteObject:[jsonTitle objectAtIndex:senderButton.tag]];
            
            for(NSManagedObject *deleteData in fetchObjects){
                
                [context deleteObject:deleteData];
                
            }
            
            
            [myTableView reloadData];
            [myTableView layoutIfNeeded];
            
        }];
        
        
        UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"No" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action){ }];
        
        
        
        [alert addAction:action1];
        [alert addAction: action2];
        [self presentViewController:alert animated:YES completion:nil];
    
    
}else {
        // There's no job with same id. Use insert method

                NSManagedObject *info = [NSEntityDescription insertNewObjectForEntityForName:@"JobsEntity" inManagedObjectContext:context];
        
        
                [info setValue:string1 forKey:@"jobsTitle"];
                [info setValue:string2 forKey:@"orgName"];
                [info setValue:string3 forKey:@"departName"];
                [info setValue:string4 forKey:@"location"];
                [info setValue:string5 forKey:@"sDate"];
                [info setValue:string6 forKey:@"eDate"];
                [info setValue:string7 forKey:@"applyURL"];
                [info setValue:string8 forKey:@"positionID"];
        
                // [jsonTitle.senderButton.tag]
        
        
                NSLog(@"Inserting.....");
        

                
                if(![context save:&error]){
                    NSLog(@"Save failed");
                }
    
                else{
                    
                    UIImage *btnImage1 = [UIImage imageNamed:@"USALoveB.png"];
                    [senderButton setImage:btnImage1 forState:UIControlStateNormal];

                }
}
        //For filtered favorite
    }else{
        
        
        NSLog(@"Tapped on favorite!");
        
        UIButton *senderButton = (UIButton *)sender;
        
        NSLog(@"Current row is: =%ld", (long)senderButton.tag);
        
        
        
        USAJobObject *NewObject = [filteredString objectAtIndex:senderButton.tag];
        
        NSString *string1 = NewObject.myTitle;
        NSString *string2 = NewObject.OrgName;
        NSString *string3  = NewObject.DepartName;
        NSString *string4  = NewObject.Location;
        NSString *string5  = NewObject.DateOpen;
        NSString *string6  = NewObject.DateClose;
        NSString *string7 = NewObject.ApplyUrl;
        NSString *string8 = NewObject.PositionId;
        //NSString *string8;
        
        NSManagedObjectContext *context = [self managedObjectContext];
        
        
        
        NSFetchRequest *request = [[NSFetchRequest alloc] init];
        request.entity = [NSEntityDescription entityForName:@"JobsEntity" inManagedObjectContext:context];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"positionID = %@", string8];
        request.predicate = predicate;
        NSError *error = nil;
        NSArray *fetchObjects = [context executeFetchRequest:request error:&error];
        if (error) {
            [NSException raise:@"no job found" format:@"%@", [error localizedDescription]];
        }
        
        if (fetchObjects.count > 0) {
            
            // There is a job with same id exsist. Use update method
            [request setPredicate:predicate];
            
            NSLog(@"UpdatingSQ.....");
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Alert?" message:@"Are you sure you want to delete this item from favorite list?" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"Yes!" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
                
                
                // Delete object from database
                NSManagedObjectContext *context = [self managedObjectContext];
                //[context deleteObject:[jsonTitle objectAtIndex:senderButton.tag]];
                
                for(NSManagedObject *deleteData in fetchObjects){
                    
                    [context deleteObject:deleteData];
                    
                }
                
                
                [myTableView reloadData];
                [myTableView layoutIfNeeded];
                
            }];
            
            
            UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"No" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action){ }];
            
            
            
            [alert addAction:action1];
            [alert addAction: action2];
            [self presentViewController:alert animated:YES completion:nil];
            
            
        }else {
            // There's no job with same id. Use insert method
            
            NSManagedObject *info = [NSEntityDescription insertNewObjectForEntityForName:@"JobsEntity" inManagedObjectContext:context];
            
            
            [info setValue:string1 forKey:@"jobsTitle"];
            [info setValue:string2 forKey:@"orgName"];
            [info setValue:string3 forKey:@"departName"];
            [info setValue:string4 forKey:@"location"];
            [info setValue:string5 forKey:@"sDate"];
            [info setValue:string6 forKey:@"eDate"];
            [info setValue:string7 forKey:@"applyURL"];
            [info setValue:string8 forKey:@"positionID"];
            
            // [jsonTitle.senderButton.tag]
            
            
            NSLog(@"Inserting.....");
            
            
            
            if(![context save:&error]){
                NSLog(@"Save failed");
            }
            
            else{
                
                UIImage *btnImage1 = [UIImage imageNamed:@"USALoveB.png"];
                [senderButton setImage:btnImage1 forState:UIControlStateNormal];
                
            }
        }
    
        
        
        
    }

    
}

- (IBAction)shareActionButton:(id)sender
{

    if(isFilltered){
        UIButton *senderButton = (UIButton *)sender;
        USAJobObject *obj = [filteredString objectAtIndex:senderButton.tag];
        
        
        NSString *shareText = obj.myTitle;
        NSString *shareText2 = obj.DepartName;
        NSString *shareText3 = obj.OrgName;
        NSString *shareText4 = obj.ApplyUrl;
        
        NSArray *itemsToShare = @[shareText,shareText3,shareText2,shareText4];
        
        
        
        
        UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:itemsToShare applicationActivities:nil];
        
        //    activityVC.excludedActivityTypes = @[UIActivityTypePostToWeibo,UIActivityTypePostToTwitter,UIActivityTypePostToFacebook,UIActivityTypeMail,UIActivityTypeMessage,UIActivityTypeAssignToContact,UIActivityTypePostToTencentWeibo];
        
        
        
        [self presentViewController:activityVC animated:YES completion:nil];
    }else{
        
        UIButton *senderButton = (UIButton *)sender;
        USAJobObject *obj = [jsonTitle objectAtIndex:senderButton.tag];
        
        
        NSString *shareText = obj.myTitle;
        NSString *shareText2 = obj.DepartName;
        NSString *shareText3 = obj.OrgName;
        NSString *shareText4 = obj.ApplyUrl;
        
        NSArray *itemsToShare = @[shareText,shareText3,shareText2,shareText4];
        
        
        
        
        UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:itemsToShare applicationActivities:nil];
        
        //    activityVC.excludedActivityTypes = @[UIActivityTypePostToWeibo,UIActivityTypePostToTwitter,UIActivityTypePostToFacebook,UIActivityTypeMail,UIActivityTypeMessage,UIActivityTypeAssignToContact,UIActivityTypePostToTencentWeibo];
        
        
        
        [self presentViewController:activityVC animated:YES completion:nil];
        
    }
    
}

- (IBAction)btnDelete:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    [myTableView setEditing:sender.selected animated:YES];
    
    if(arrayToDelete.count){
        
        for(NSString *str in arrayToDelete){
            [arrayData removeObject:str];
            
        }
        [arrayToDelete removeAllObjects];
        [myTableView reloadData];
    }
    
    NSLog(@"One Added:");
}


@end
