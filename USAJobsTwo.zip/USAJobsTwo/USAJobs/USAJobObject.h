//
//  NiceController.h
//  USAJobs
//
//  Created by Yahya  on 7/20/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface USAJobObject : NSObject

@property (nonatomic, copy)NSString *myTitle;
@property (nonatomic, copy)NSString *OrgName;
@property (nonatomic, copy)NSString *DepartName;
@property (nonatomic, copy)NSString *Location;
@property (nonatomic, copy)NSString *DateOpen;
@property (nonatomic, copy)NSString *DateClose;


@property (nonatomic, copy)NSString *Salary;
@property (nonatomic, copy)NSString *Agency;
@property (nonatomic, copy)NSString *ShiftType;
@property (nonatomic, copy)NSString *ApplyUrl;
@property (nonatomic, copy)NSString *PositionId;


@property(nonatomic, retain)USAJobObject *cellSight;
@property(nonatomic, strong)NSMutableArray *sitesArray;


-(void)loadData;

@end
