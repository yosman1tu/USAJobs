//
//  SearchingViewController.h
//  Search
//
//  Created by Yahya  on 7/23/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface SearchingViewController : UIViewController<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate>
{
    //    NSMutableArray *jsonTitle;
    //    NSArray *originalData;
    //    NSMutableArray *searchData;
    //    NSMutableArray *jsonContentItem;
    //
    //    UISearchBar *searchBar;
        UISearchDisplayController *searchDisplayController;
    //
    //    NSMutableArray *filteredString;
    //    BOOL isFilltered;
    
    
    IBOutlet UITableView *myTableView;
    IBOutlet UISearchBar *searchBar;
    
    NSMutableArray *allItems;
    NSMutableArray *displayItems;
    NSMutableArray *jsonTitle;
    
    NSMutableArray *filteredString;
    BOOL isFilltered;
    
    
    NSMutableArray *arrayData;
    NSMutableArray *arrayToDelete;  
}

@property(nonatomic, strong)NSMutableArray *filteredString;

@property (strong, nonatomic)NSArray * shareArrayS;
;


@property(nonatomic, strong)NSMutableArray *jsonTitle;

@property(nonatomic, strong)NSMutableArray *jsonContent;

@property(nonatomic, strong)NSMutableArray *FavoriteArray;


@property(nonatomic, strong)NSMutableArray *contentItem;





//- (IBAction)FavBtn:(id)sender;


- (IBAction)btnDelete:(id)sender;

@end
