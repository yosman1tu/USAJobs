//
//  FavoriteDetailView.h
//  USAJobs
//
//  Created by Yahya  on 8/22/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>


@class JobInfo;
@interface FavoriteDetailView : UIViewController

@property(nonatomic, strong)IBOutlet UIWebView *WebView;

@property(nonatomic, strong)NSString *contentText;



@property(nonatomic, retain)JobInfo *objectManager;

@end
