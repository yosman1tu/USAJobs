//
//  JobDetailViewController.m
//  USAJobs
//
//  Created by Yahya  on 8/10/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "JobDetailViewController.h"
#import "TableViewCell.h"
//#import "SearchingViewController.h"


@interface JobDetailViewController ()

@end

@implementation JobDetailViewController


@synthesize titleText, titleTextLabel, great,contentView;



-(id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if(self){
        //Custom initialization
        
    }
    return self;
}

-(void)displayContent:(NSString *)string
{
    
    
    NSMutableArray *html = [NSMutableString stringWithString:string];
    
    
    
    [self.contentView setBackgroundColor:[UIColor clearColor]];
    [self.contentView loadHTMLString:[html description] baseURL:nil];
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    //self.titleTextLabel.text = great.myTitle;
    //self.contentText = great.ApplyUrl;
    
//    UINavigationBar *navbar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 0, 375, 55)];
//    //do something like background color, title, etc you self
//    [self.view addSubview:navbar];
//    
//    UINavigationItem *item = [[UINavigationItem alloc]
//                              init];
//    navbar.items= @[item];
//    UIBarButtonItem *backButton = [[UIBarButtonItem alloc]
//                                   initWithTitle:@"< Back"
//                                   style:UIBarButtonItemStyleBordered
//                                   target:self
//                                   action:@selector(backBtnClicked:)];
//    item.leftBarButtonItem = backButton;
    
//    UINavigationBar *navbar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 0, 375, 55)];
//    
//    UINavigationItem *item = [[UINavigationItem alloc]
//                                                            init];
//                                  navbar.items= @[item];
//    
//    UIBarButtonItem *backButton = [[UIBarButtonItem alloc]
//                                                                      initWithTitle:@"< Back"
//                                                                      style:UIBarButtonItemStyleBordered
//                                                                      target:self
//                                                                      action:@selector(backBtnClicked:)];
//    
//    [self.navigationItem setLeftBarButtonItem:backButton];
//    
    ///////
    
    NSLog(@"This what: %@", self.self.contentText);
    
    NSURL *myURL = [NSURL URLWithString:[great.ApplyUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];    NSURLRequest *requestURL = [NSURLRequest requestWithURL:myURL];
    
    [contentView loadRequest:requestURL];
    
    //NSLog(@"This what: %@", self.contentText);
    
    //[self displayContent:self.contentText];
    
    
}

- (void) viewWillAppear:(BOOL)animated
{
        [super viewWillAppear:animated];
    

    
    [self.navigationController setNavigationBarHidden:NO animated:animated];

}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of
}
//- (IBAction)BackButton:(id)sender {
//    
//    [self dismissViewControllerAnimated:YES completion:nil]; // ios 6
//    //[[self navigationController] popViewControllerAnimated:YES];
//    
//}
@end
