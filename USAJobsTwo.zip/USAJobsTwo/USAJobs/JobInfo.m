//
//  JobInfo.m
//  USAJobs
//
//  Created by Yahya  on 8/22/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "JobInfo.h"

@implementation JobInfo

@dynamic jobsTitle;
@dynamic orgName;
@dynamic departName;
@dynamic applyURL;

@end
