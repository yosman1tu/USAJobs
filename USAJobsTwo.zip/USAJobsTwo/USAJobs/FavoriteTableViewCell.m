//
//  FavoriteTableViewCell.m
//  USAJobs
//
//  Created by Yahya  on 8/19/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "FavoriteTableViewCell.h"

#import "FavoriteViewController.h"



@implementation FavoriteTableViewCell

@synthesize Favtitle,OrgNameFav,DepartNameFav,LocationFav,DateEnd,DateStart,ApplyFav;


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}




-(void)setFavDetails:(JobInfo *) new
{
     Favtitle.text = new.jobsTitle;
     OrgNameFav.text = new.orgName;

     DepartNameFav.text = new.departName;
     LocationFav.text = new.location;
     DateStart.text = new.sDate;
     DateEnd.text = new.eDate;
    ApplyFav.text = new.applyURL;

}

@end
