//
//  WebViewController.m
//  NewsImages
//
//  Created by Yahya  on 6/22/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "WebViewController.h"
#import "TableViewCell.h"

@interface WebViewController ()



@end

@implementation WebViewController
@synthesize titleText, titleTextLabel, great,contentView;



-(id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if(self){
        //Custom initialization
        
    }
    return self;
}

-(void)displayContent:(NSString *)string
{
    NSMutableArray *html = [NSMutableString stringWithString:string];
    
    
    
    [self.contentView setBackgroundColor:[UIColor clearColor]];
    [self.contentView loadHTMLString:[html description] baseURL:nil];
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //self.titleTextLabel.text = great.myTitle;
    //self.contentText = great.ApplyUrl;

    
    
    
    //self.contentText = @"https://www.usajobs.gov:443/GetJob/ViewDetails/461712200?PostingChannelID=RESTAPI";
    
     NSLog(@"This what: %@", self.self.contentText);
    
    NSURL *myURL = [NSURL URLWithString:[self.contentText stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];    NSURLRequest *requestURL = [NSURLRequest requestWithURL:myURL];
    
    [contentView loadRequest:requestURL];
    
    //NSLog(@"This what: %@", self.contentText);
    
    //[self displayContent:self.contentText];
    
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
