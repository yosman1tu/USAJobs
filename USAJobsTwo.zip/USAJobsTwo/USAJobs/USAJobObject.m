//
//  NiceController.m
//  USAJobs
//
//  Created by Yahya  on 7/20/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "USAJobObject.h"
#import "TableViewCell.h"
#import "SearchingViewController.h"


@implementation USAJobObject

@synthesize myTitle,ApplyUrl;

-(void)loadData
{
   // NSURL *url = [NSURL URLWithString:self.ApplyUrl];
    //NSData *imageData = [[NSData alloc] initWithContentsOfURL:urlL];
    
    // NSLog(@"This is myUrl:", url);
    //self.imageData = [NSData dataWithContentsOfURL:url];
    
}



@end
