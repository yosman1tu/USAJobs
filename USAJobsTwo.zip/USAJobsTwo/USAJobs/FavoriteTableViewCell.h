//
//  FavoriteTableViewCell.h
//  USAJobs
//
//  Created by Yahya  on 8/19/17.
//  Copyright © 2017 Towson University. All rights reserved.
//


//@class USAJobObject;

#import <UIKit/UIKit.h>
#import "JobInfo.h"
@interface FavoriteTableViewCell : UITableViewCell <UIGestureRecognizerDelegate>



@property (strong, nonatomic) IBOutlet UILabel *Favtitle;
@property (strong, nonatomic) IBOutlet UILabel *OrgNameFav;

@property (strong, nonatomic) IBOutlet UILabel *DepartNameFav;

@property (strong, nonatomic) IBOutlet UILabel *LocationFav;

@property (strong, nonatomic) IBOutlet UILabel *DateStart;
@property (strong, nonatomic) IBOutlet UILabel *DateEnd;

@property (strong, nonatomic) IBOutlet UILabel *ApplyFav;



-(void)setFavDetails:(JobInfo *) new;



@end
