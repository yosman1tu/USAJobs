//
//  TableViewCell.h
//  USAJobs
//
//  Created by Yahya  on 7/21/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "USAJobObject.h"
//#import "TableViewCell.h"
//#import "SearchingViewController.h"



@interface TableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *title;

@property (strong, nonatomic) IBOutlet UILabel *myLocation;

@property (strong, nonatomic) IBOutlet UILabel *Organization;

@property (strong, nonatomic) IBOutlet UILabel *Department;

@property (strong, nonatomic) IBOutlet UILabel *Date;

@property (strong, nonatomic) IBOutlet UILabel *DateC;

@property (strong, nonatomic) IBOutlet UILabel *PostId;



@property (strong, nonatomic) IBOutlet UILabel *Apply;

@property (strong, nonatomic) IBOutlet UIButton *FavBtn;

- (IBAction)FavoriteBtn:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *shareButton;

- (IBAction)shareActionButton:(id)sender;



-(void)setDetails:(USAJobObject *) new;



@end
