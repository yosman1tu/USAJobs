//
//  FavoriteDetailView.m
//  USAJobs
//
//  Created by Yahya  on 8/22/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "FavoriteDetailView.h"
#import "FavoriteTableViewCell.h"

@interface FavoriteDetailView ()

@end

@implementation FavoriteDetailView

@synthesize  objectManager,contentText,WebView;



-(id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if(self){
        //Custom initialization
        
    }
    return self;
}

-(void)displayContent:(NSString *)string
{
    
    
    NSMutableArray *html = [NSMutableString stringWithString:string];
    
    
    
    [self.WebView setBackgroundColor:[UIColor clearColor]];
    [self.WebView loadHTMLString:[html description] baseURL:nil];
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    //self.titleTextLabel.text = great.myTitle;
    self.contentText = objectManager.applyURL;
    
 
    
    NSLog(@"This what: %@", self.self.contentText);
    
    NSURL *myURL = [NSURL URLWithString:[contentText stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];    NSURLRequest *requestURL = [NSURLRequest requestWithURL:myURL];
    
    [WebView loadRequest:requestURL];
    
    //NSLog(@"This what: %@", self.contentText);
    
    //[self displayContent:self.contentText];
    
    
}

- (void) viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    [super viewWillAppear:animated];
}


@end
