//
//  JobDetailViewController.h
//  USAJobs
//
//  Created by Yahya  on 8/10/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>

@class USAJobObject;

@interface JobDetailViewController : UIViewController

@property(nonatomic, strong)IBOutlet UILabel *titleTextLabel;
@property(nonatomic, strong)IBOutlet UIWebView *contentView; //webView

@property(nonatomic, strong)NSString *titleText;
@property(nonatomic, strong)NSString *contentText;

@property (copy, nonatomic) NSString *url;

@property (nonatomic, strong) NSString *newsTitle;

@property(nonatomic, strong)IBOutlet UILabel *urlTextField;

@property(nonatomic, retain)USAJobObject *great;



@end
