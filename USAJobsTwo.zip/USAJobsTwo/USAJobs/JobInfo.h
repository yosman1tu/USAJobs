//
//  JobInfo.h
//  USAJobs
//
//  Created by Yahya  on 8/22/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface JobInfo : NSManagedObject

@property (nonatomic, retain) NSString * jobsTitle;
@property (nonatomic, retain) NSString * orgName;

@property (nonatomic, retain) NSString * departName;

@property (nonatomic, retain) NSString * location;

@property (nonatomic, retain) NSString * sDate;

@property (nonatomic, retain) NSString * eDate;

@property (nonatomic, retain) NSString * applyURL;

//@property (nonatomic, retain) NSString * jobsTitle;



@end
