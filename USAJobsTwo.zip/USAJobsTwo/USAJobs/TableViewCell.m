//
//  TableViewCell.m
//  USAJobs
//
//  Created by Yahya  on 7/21/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "TableViewCell.h"
//#import "USAJobObject.h"


@implementation TableViewCell

@synthesize title, myLocation, Organization, Department, Date, DateC, Apply;


-(void)setDetails:(USAJobObject *) new
{
    title.text = new.myTitle;
    
    myLocation.text = new.Location;
    
    Organization.text = new.OrgName;
    
    Department.text = new.DepartName;
    
    Date.text = new.DateOpen;
    
    DateC.text = new.DateClose;
    
    Apply.text = new.ApplyUrl;
    
}

- (IBAction)shareActionButton:(id)sender {
}
@end
