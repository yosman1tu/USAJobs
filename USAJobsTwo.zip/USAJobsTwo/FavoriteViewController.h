//
//  FavoriteViewController.h
//  USAJobs
//
//  Created by Yahya  on 8/19/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>


@interface FavoriteViewController : UIViewController <NSFetchedResultsControllerDelegate,UITableViewDelegate,UITableViewDataSource>


@property (strong, nonatomic) IBOutlet UITableView *FavoriteTableView;

@property(nonatomic, strong)NSMutableArray *array;

@property(nonatomic, strong)NSString *jobHolder;

//@property(nonatomic, strong)UISwipeGestureRecognizer *leftSwipeGesture;


@property (nonatomic,strong) NSManagedObjectContext* managedObjectContext;
@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;
@property (readonly, strong)  NSPersistentStoreCoordinator *persistentStoreCoordinator;


@property (strong, nonatomic)NSMutableArray *mutableArray;





@end
